/*
 *  DLL.C
 */ 
#include <stddef.h>
#include <stdio.h>
#include <windows.h>
#include "dll32.h"

#ifdef __386__
#define DLL_ID "DLL32"
#else
#define DLL_ID "DLL16"
typedef long( FAR PASCAL *FPROC )();
FPROC funcp;
#endif

#ifdef __386__
int FAR PASCAL LibMain( HANDLE dll,
                      DWORD reason,
                      LPVOID reserved )
/****************************************/
{
    return( TRUE );
}
#else
BOOL FAR PASCAL LibMain( HANDLE instance, WORD data_segment,
                         WORD heap_size, LPSTR cmd_line )
/**********************************************************/
{
    return( TRUE );
}
#endif
