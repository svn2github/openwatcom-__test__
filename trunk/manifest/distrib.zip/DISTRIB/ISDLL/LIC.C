#include <string.h>
#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>
#include <wtypes.h>

#include "standard.h"
#include "license.h"

void Debug( char *text )
/**********************/
{
    MessageBox( NULL, text, "INFORMATION", MB_OK );
}

static WORD NoHardErrors()
/************************/
{
    WORD 		old_mode;

    old_mode = 0;
    #if defined(__OS2__)
        DosError( FERR_DISABLEHARDERR );
    #elif defined(__DOS__)
        _harderr( (HANDLER __far*)critical_error_handler );
    #elif defined( __WINDOWS__) || defined(__NT__)
        old_mode = SetErrorMode( SEM_FAILCRITICALERRORS );
    #endif

    return old_mode;
}

static void ResetHardErrors( WORD old_mode )
/******************************************/
{
    #if defined( __WINDOWS__) || defined(__NT__)
        SetErrorMode( old_mode );
    #endif
}

#ifdef __386__
char * FAR PASCAL DLLApplyLicenseToExe( char	*exename,
                                        char	*licname,
                                        char	*name,
                                        char	*compname,
                                        int	*tryagain )
#else
char * __export FAR PASCAL DLLApplyLicenseToExe( char	*exename,
                                                 char	*licname,
                                                 char	*name,
                                                 char	*compname,
                                                 int	*tryagain )
#endif
/*****************************************************************/
{
    WORD		old_err_mode;
    char *		return_value;

    old_err_mode = NoHardErrors();
    return_value = apply_license_to_exe( exename, licname, name, compname, tryagain );
    ResetHardErrors( old_err_mode );

    return return_value;
}

#ifdef __386__
char * FAR PASCAL DLLFindLicenseNames( char * 			licfile,
                                       char * 			name,
		                       char * 			compname,
		                       int *			tryagain )
#else
char * __export FAR PASCAL DLLFindLicenseNames( char *		licfile,
                                                char * 		name,
		                                char * 		compname,
		                                int *		tryagain )
#endif
/************************************************************************/
{
    char *		err;
    char *		liccompname;
    char *		licname;
    WORD		old_err_mode;

    old_err_mode = NoHardErrors();

    licname = NULL;
    liccompname = NULL;
    err = find_license_names( licfile, &licname, &liccompname, tryagain );
    if( licname != NULL ) {
        strcpy( name, licname );
    }
    if( liccompname != NULL ) {
        strcpy( compname, liccompname );
    }

    ResetHardErrors( old_err_mode );

    return err;
}
