//   **********************************************************************
//   * module:      rver.c                                                *
//   * abstract:    This module contains the api to read an NLM header    *
//   *              and extract version information.                      *
//   *                                                                    *
//   * (c) Copyright. 1989-1993 Novell, Inc.   All rights reserved.       *
//   *                                                                    *
//   * environment: NetWare 3.x and 4.x                                   *
//   *              WATCOM C 9.01                                         *
//   **********************************************************************
//   * maintenance history:                                               *
//   * level    date      pi   description                                *
//   **********************************************************************
//   *  001   08/10/93    kl   initial release.                           *
//   **********************************************************************

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <io.h>
#include <fcntl.h>

#include "dll32.h"
#include "nlmver.h"

static void LenToASCIIZStr(char *tobuf, char *frombuf)
/********************************************************/
{
        memcpy(tobuf,frombuf+1,*frombuf);
        tobuf[*frombuf] = NULL;
}

int     ReturnNLMVersionInfoFromFile
/**********************************/
(
BYTE *	__pathName,
LONG *	majorVersion,
LONG *	minorVersion,
LONG *	revision,
LONG *	year,
LONG *	month,
LONG *	day,
BYTE *	copyrightString,
BYTE *	description
)
{
	int	    handle, bytes, offset, found = FALSE;
	LONG *	    verPtr;
	NLMHDR *    nlmHeader;
	BYTE	    buffer[READ_SIZE];

        handle = open(__pathName, O_BINARY | O_RDONLY, 0);
        if (handle != EFAILURE)
        {
            bytes = read(handle, buffer, READ_SIZE);
            close(handle);
            if (bytes == READ_SIZE)
            {
                if (description)
                {
                    nlmHeader = (NLMHDR *)buffer;
                    LenToASCIIZStr(description, &(nlmHeader->descriptionLength));
                }

                for (offset = 0; !found && (offset < READ_SIZE); offset++)
                    if (!memcmp("VeRsIoN", &buffer[offset], 7) )
                        found = TRUE;
                if (found)
                {
                    verPtr = (LONG *)(&buffer[offset+7]);
                    if (majorVersion) *majorVersion = *verPtr++;
                    if (minorVersion) *minorVersion = *verPtr++;
                    if (revision)     *revision     = *verPtr++;
                    if (year)         *year         = *verPtr++;
                    if (month)        *month        = *verPtr++;
                    if (day)          *day          = *verPtr++;

                    found = FALSE;
                    for (; !found && (offset < READ_SIZE); offset++)
                        if (!memcmp("CoPyRiGhT", &buffer[offset], 9) )
                            found = TRUE;
                    if (found)
                        if (copyrightString)
                            LenToASCIIZStr(copyrightString,&buffer[offset+9]);
                    return(ESUCCESS);
                }
            }
        }
    return(EFAILURE);
}

#define NEWERNLM                    TRUE        // NLM newer than present
#define OLDERNLM                    FALSE       // NLM older than present
#define SAMENLM                     FALSE       // Same versions
#define BAD_PATH_NAME               TRUE        // Version info not found
#define NOT_IN_SYSTEM_DIRECTORY     TRUE        // NLM not found

char sysPath[] = { "SYS:\\SYSTEM\\" };

long FAR PASCAL CheckNewer( char *newNLM, char *oldNLM, VERS * vers )
/*******************************************************************/
{
        int  rc;
        LONG year, month, day;
        LONG newyear, newmonth, newday;
        LONG majorVersion, minorVersion, revision;
        LONG newmajorVersion, newminorVersion, newrevision;

        memset( vers, 0, sizeof( VERS ) );

        /* Get the new NLMs creation date */

        if(rc = ReturnNLMVersionInfoFromFile(newNLM, &newmajorVersion,
                &newminorVersion, &newrevision, &newyear, &newmonth, &newday,
                NULL, NULL))
                return BAD_PATH_NAME;

        /* Get the old NLMs creation date */

        if(rc = ReturnNLMVersionInfoFromFile(oldNLM, &majorVersion,
                        &minorVersion, &revision, &year, &month, &day,
                        NULL, NULL)){
                        return NOT_IN_SYSTEM_DIRECTORY;
        }
	vers->majorVersion = majorVersion;
	vers->minorVersion = minorVersion;
	vers->revision = revision;
	vers->year = year;
	vers->month = month;
	vers->day = day;

	vers->newmajorVersion = newmajorVersion;
	vers->newminorVersion = newminorVersion;
	vers->newrevision = newrevision;
	vers->newyear = newyear;
	vers->newmonth = newmonth;
	vers->newday = newday;
	vers->filled = 1;

        if(newmajorVersion > majorVersion) return NEWERNLM;
        if(newmajorVersion < majorVersion) return OLDERNLM;

        if(newminorVersion > minorVersion) return NEWERNLM;
        if(newminorVersion < minorVersion) return OLDERNLM;

        if(newrevision > revision)         return NEWERNLM;
        if(newrevision < revision)         return OLDERNLM;

        if(newyear > year)                 return NEWERNLM;
        if(newyear < year)                 return OLDERNLM;

        if(newmonth > month)               return NEWERNLM;
        if(newmonth < month)               return OLDERNLM;

        if(newday > day)                   return NEWERNLM;
        if(newday < day)                   return OLDERNLM;

        /* must be the identical file */
        return SAMENLM;
}

